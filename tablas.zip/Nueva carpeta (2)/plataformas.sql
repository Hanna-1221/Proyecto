-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 03-06-2024 a las 05:09:49
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `plataformas`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `compra`
--

CREATE TABLE `compra` (
  `IDE_COMPRA` int(12) NOT NULL,
  `NUM_PERSONA` int(12) NOT NULL,
  `IDE_PRODUCTO` int(12) NOT NULL,
  `IDE_ESTADO` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `compra`
--

INSERT INTO `compra` (`IDE_COMPRA`, `NUM_PERSONA`, `IDE_PRODUCTO`, `IDE_ESTADO`) VALUES
(1, 1, 2, 1),
(2, 2, 1, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `persona`
--

CREATE TABLE `persona` (
  `NUM_IDENTIFICACION` int(12) NOT NULL,
  `NOM_PERSONA` varchar(50) NOT NULL,
  `DSC_NACIONALIDAD` varchar(50) NOT NULL,
  `FEC_NACIMIENTO` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `persona`
--

INSERT INTO `persona` (`NUM_IDENTIFICACION`, `NOM_PERSONA`, `DSC_NACIONALIDAD`, `FEC_NACIMIENTO`) VALUES
(1, 'Juan Perez', 'Costarricense', '1997-01-01'),
(2, 'Mayela Quesada', 'Colombiana', '1985-01-01');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `producto`
--

CREATE TABLE `producto` (
  `IDE_PRODUCTO` int(12) NOT NULL,
  `NOM_PRODUCTO` varchar(50) NOT NULL,
  `DSC_PROVEEDOR` varchar(50) NOT NULL,
  `IDE_ESTADO` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `producto`
--

INSERT INTO `producto` (`IDE_PRODUCTO`, `NOM_PRODUCTO`, `DSC_PROVEEDOR`, `IDE_ESTADO`) VALUES
(1, 'Helado', 'Dos Pinos', 1),
(2, 'Pasta', 'Roma', 1);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `ver_compra`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `ver_compra` (
`IDE_COMPRA` int(12)
,`NUM_PERSONA` int(12)
,`IDE_PRODUCTO` int(12)
,`IDE_ESTADO` int(2)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `ver_detalle_compra`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `ver_detalle_compra` (
`NOM_PERSONA` varchar(50)
,`DSC_NACIONALIDAD` varchar(50)
,`NOM_PRODUCTO` varchar(50)
,`DSC_PROVEEDOR` varchar(50)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `ver_persona`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `ver_persona` (
`NUM_IDENTIFICACION` int(12)
,`NOM_PERSONA` varchar(50)
,`DSC_NACIONALIDAD` varchar(50)
,`FEC_NACIMIENTO` date
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `ver_producto`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `ver_producto` (
`IDE_PRODUCTO` int(12)
,`NOM_PRODUCTO` varchar(50)
,`DSC_PROVEEDOR` varchar(50)
,`IDE_ESTADO` int(11)
);

-- --------------------------------------------------------

--
-- Estructura para la vista `ver_compra`
--
DROP TABLE IF EXISTS `ver_compra`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `ver_compra`  AS SELECT `compra`.`IDE_COMPRA` AS `IDE_COMPRA`, `compra`.`NUM_PERSONA` AS `NUM_PERSONA`, `compra`.`IDE_PRODUCTO` AS `IDE_PRODUCTO`, `compra`.`IDE_ESTADO` AS `IDE_ESTADO` FROM `compra` ;

-- --------------------------------------------------------

--
-- Estructura para la vista `ver_detalle_compra`
--
DROP TABLE IF EXISTS `ver_detalle_compra`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `ver_detalle_compra`  AS SELECT `p`.`NOM_PERSONA` AS `NOM_PERSONA`, `p`.`DSC_NACIONALIDAD` AS `DSC_NACIONALIDAD`, `pr`.`NOM_PRODUCTO` AS `NOM_PRODUCTO`, `pr`.`DSC_PROVEEDOR` AS `DSC_PROVEEDOR` FROM ((`compra` `c` join `persona` `p` on(`c`.`NUM_PERSONA` = `p`.`NUM_IDENTIFICACION`)) join `producto` `pr` on(`pr`.`IDE_PRODUCTO` = `c`.`IDE_PRODUCTO`)) ;

-- --------------------------------------------------------

--
-- Estructura para la vista `ver_persona`
--
DROP TABLE IF EXISTS `ver_persona`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `ver_persona`  AS SELECT `persona`.`NUM_IDENTIFICACION` AS `NUM_IDENTIFICACION`, `persona`.`NOM_PERSONA` AS `NOM_PERSONA`, `persona`.`DSC_NACIONALIDAD` AS `DSC_NACIONALIDAD`, `persona`.`FEC_NACIMIENTO` AS `FEC_NACIMIENTO` FROM `persona` ;

-- --------------------------------------------------------

--
-- Estructura para la vista `ver_producto`
--
DROP TABLE IF EXISTS `ver_producto`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `ver_producto`  AS SELECT `producto`.`IDE_PRODUCTO` AS `IDE_PRODUCTO`, `producto`.`NOM_PRODUCTO` AS `NOM_PRODUCTO`, `producto`.`DSC_PROVEEDOR` AS `DSC_PROVEEDOR`, `producto`.`IDE_ESTADO` AS `IDE_ESTADO` FROM `producto` ;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `persona`
--
ALTER TABLE `persona`
  ADD PRIMARY KEY (`NUM_IDENTIFICACION`);

--
-- Indices de la tabla `producto`
--
ALTER TABLE `producto`
  ADD PRIMARY KEY (`IDE_PRODUCTO`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
